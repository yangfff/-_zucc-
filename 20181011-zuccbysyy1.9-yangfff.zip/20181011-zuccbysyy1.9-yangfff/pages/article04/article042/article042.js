// pages/article04/article042/article042.js
const app = getApp();

Page({
  data: {
    article: [
      {
        title: "【博雅·课程】精彩纷呈的博雅课程\n_______________________________________________________\n\n_______________________________________________________\n",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-课程介绍封面图.jpg",
        content: "【博雅·课程】精彩纷呈的博雅课程"
      },

      {
        title: "【博古通今 丈量世界】之陶艺是一种文化\n",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-陶艺课.jpg",
        content: "陶艺"
      }
      ,

      {
        title: "【博古通今 丈量世界】之有戏的人生才有味儿（曲艺主题课程）\n",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-戏曲课.jpg",
        content: "张如仟"
      }
      ,

      {
        title: "【博古通今 丈量世界】之一枝谈贮书窗下，人与花心各自香",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-花艺课.jpg",
        content: ""
      }
      ,
      {
        title: "【博古通今 丈量世界】之华夏有衣，名曰汉服",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-汉服课.jpg",
        content: ""
      }
      ,
      {
        title: "【博古通今 丈量世界】之览博古之物，习风雅之姿（古物鉴赏课程）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-古物鉴赏课.jpg",
        content: ""
      }
      ,
      {
        title: "【博古通今 丈量世界】之一枝谈贮书窗下，人与花心各自香",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-花艺课.jpg",
        content: ""
      }
      ,

    

      {
        title: "【博古通今 丈量世界】之越女新妆出镜心，自知明艳更沉吟（美妆课程）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-化妆课.jpg",
        content: "伍曼菱"
      }
      ,
      
      {
        title: "【博古通今 丈量世界】之音乐·人生",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-音乐课.jpg",
        content: ""
      }
      , 
      {
        title: "【博古通今 丈量世界】之世人闻秋悲寂寥，我道秋日胜春朝（哲学主题课程）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-哲学课.jpg",
        content: ""
      }, 
      {
        title: "【礼仪规范 学以致用】之无处不在的礼仪（不同场合的礼仪）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-礼仪课.jpg",
        content: ""
      }
      ,
      {
        title: "【礼仪规范 学以致用】之男人穿魅力，女人穿规则",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-着装活动礼仪.jpg",
        content: ""
      }
      , ,
      {
        title: "【礼仪规范 学以致用】之学会沟通 拯救尬聊",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-拯救尬聊课程.jpg",
        content: ""
      }
      , ,
      {
        title: "【通用礼仪规范课程】之尚礼施行, 博雅修身（形体礼仪）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011课程介绍形体礼仪.jpg",
        content: ""
      }
      , ,
      {
        title: "【通用礼仪规范课程】之礼者，人之所履（商务形体礼仪）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-商务形体礼仪.jpg",
        content: ""
      }
      ,
      {
        title: "【通用礼仪规范课程】之活动方寸亦有礼，工作之中存艺术（着装和活动礼仪）",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-着装活动礼仪.jpg",
        content: ""
      }
      ,
      {
        title: "【茶学茶艺 闲情偶寄】之中国茶文化漫谈",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-茶道.jpg",
        content: ""
      }
      , 
      {
        title: "【茶学茶艺 闲情偶寄】之茶如人生，品味传统",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-课程介绍-品茶课.jpg",
        content: ""
      }
      , 
      {
        title: "来博雅 陪你看遍,烟波浩渺，星辰流光。.💫\n_______________________________________________________\n未尽事宜，请咨询：胡同学（15869482980）；曾同学（13516708521）\n_______________________________________________________\n\n_______________________________________________________\n 10月14纳新当日，我们在B02摊位等你！长按上方小程序码和公众号二维码，了解更多博雅资讯！\n\n\n\n\n_______________________________________________________\n",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-纳新-二维码.png",
        content: "二维码"
      },


    ],

  },

  fHandin: function () {
    var that = this;


    wx.request({
      url: config.service.feedbackUrl,
      data: {
        team_name: that.data.team_name,
        advice1: that.data.advice1,
        advice2: that.data.advice2,
        advice3: that.data.advice3
      },
      method: 'POST',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        util.showSuccess('提交成功');
      },
      fail: function (res) {
        util.showModel('提交失败', '请检查你的网络连接是否正确');
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: 'zucc博雅书院-书院结构',
      desc: '快来pick这支超强导师、部门团队吧~',
      path: 'pages/article01/article01?id= wx0eb78264e0c81417'
    }
  },
})