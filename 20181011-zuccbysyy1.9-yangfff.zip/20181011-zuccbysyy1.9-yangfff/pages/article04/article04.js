// pages/article01/article01.js
Page({
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '【博雅|课程】往期课程一览',
      desc: 'hey！我猜这里有你感兴趣的课程，而且参与还能拿素质分，快来看看吧！',
      path: 'pages/article04/article04?id= wx0eb78264e0c81417'
    }
  },
  /**
   * 页面的初始数据
   */
  data: {

    article: [
      {
        title: "【博雅·课程】博雅书院往期课程一览",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/【博雅书院-往期课程】 900×500px.jpg",
        link: "../article04/article041/article041",
        content: "2017-2018学年\n\n\n 世人闻秋悲寂寥，我道秋日胜春朝——博雅书院哲学主题课程\n\n不傲才以骄人，不以宠而作威——学会沟通，拯救“尬聊”的沟通课程\n\n华夏有衣，名曰汉服――博雅《华夏霓裳》主题课程\n\n活动方寸亦有礼，工作之中存艺术——日常活动与工作中的礼仪\n\n “随风潜入夜，润物细无声”——收获成长的博雅志愿者培训课程\n\n一枝谈贮书窗下，人与花心各自香——博雅书院日式插花课程\n\n礼者，人之所履——博雅书院形象礼仪课程\n\n越女新妆出镜心，自知明艳更沉吟——博雅书院美妆课程\n\n矮纸斜行闲作草，竹炉汤沸火初红。——博雅书院茶艺礼仪课程\n\n\n更多课程信息，请关注“zucc博雅书院”微信公众号哦~"
      },
      {
        title: "【博雅·课程】精彩纷呈的博雅课程",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-课程介绍封面图.jpg",
        link: "../article04/article042/article042",
        content: "课程详情"
      },
      
    ]
  }
})