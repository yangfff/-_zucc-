// pages/home/home.js

Page({
  data: {
    indicatorDots: true,
    indicatorcolor: 'white',
    indicatoractivecolor: '#ADD8E6',
    autoplay: true,
    interval: 5000,
    duration: 1000,
    imgUrls: [
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/2.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/1.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅海报-博雅logo.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/4.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/7.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/10.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅海报-冬至博雅.jpg"
    ],
    article: [
      
      {
        title: "【博雅纳新|书院的可爱部门介绍】",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-部门介绍封面图.jpg",
        link: "../article01/article013/article013",
        content: "采编部：\n负责博雅书院的新闻稿和微信平台推送\n负责整合“悦”系列推送\n负责编辑学员感悟以及归档整理\n \n\宣传部：\n 负责日常课程或活动的拍照录像\n 负责制作宣传视频或者宣传册\n负责设计资信证书和结业证书\n通过线下方式宣传博雅书院\n\n秘书处：\n负责各活动的策划案、执行案和总结案的汇总\n 负责制定并执行部长和学员的培训和考核章程\n负责博雅书院各项活动财务预算全决算\n\n实践部：\n负责各类活动策划的实施、购置活动所需物品\n负责统筹博雅礼仪进分院活动\n负责统筹对外礼仪活动、学年小结、结业式等\n\n教学部：\n负责教学计划安排、联络老师、教室布置、签到结果最后统计\n负责编辑学员和后期教案的归档整理\n负责“年度优秀学员”评选\n\n"
      },
      {
        title: "【博雅纳新|书院的圆梦导师团之团队导师】",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师封面图.jpg",
        link: "../article01/article011/article011",
        content: "徐婧老师，博雅书院团队导师成员，菁礼仪形象工作室成员，国际形象礼仪培训师、中国形象礼仪讲师、中国赛会服务研究培训师、G20国际峰会志愿者形象礼仪通用培训师，国家二级心理咨询师。\n\n张如仟老师，国家高级礼仪培训师，学院博雅书院导师，计算学院学工办主任，开设《现代实用礼仪》等选修课，主讲课程《日常行为礼仪》和《社交礼仪》等。\n\n 俞诗倩老师，博雅书院团队导师成员，浙江大学城市学院学工委教师，杭州师范大学法学硕士。热爱学生工作，热爱音乐、阅读，愿陪伴同学们一起寻一场非凡的文化之旅！\n\n陈雅琪老师，博雅书院团队导师成员，浙江大学城市学院医学院学工办辅导员、医学院党员之家指导老师, 浙江大学硕士，在校曾获得国家奖学金，浙江大学优秀毕业生，三好学生，校园十佳歌手等, 热爱学生工作。\n\n胡晓倩老师，浙江大学城市学院信电分院物理实验中心老师，在校期间获得浙大十佳志愿者，拱墅区最美志愿者，杭州市属高校最美大学生，校十佳主持。感恩生活，乐于奉献，愿与大家一起把研习礼仪变成一种习惯，让微笑变成日常基调，把学习与工作变成诗。\n\n伍曼菱老师，博雅书院辅导员导师成员，学院学工委学区辅导员，菁礼仪形象工作室成员，香港大学硕士，香港大学研究生会兼职对外汉语教师，主讲课程《形体礼仪》，热衷于研习中国传统文化。\n\n"
      },
      {
        title: "【博雅纳新|书院的圆梦导师团之专业导师】",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-专业导师封面图.jpg",
        link: "../article01/article012/article012",
        content: "董尚胜老师，茶学硕士，曾任职于浙江大学茶学系，副教授，先后主讲《茶树栽培学》、《中国茶文化》、《茶叶经营管理》、《茶用香花栽培学》、《茶树生理》、《植物有效成份的分离提取》等课程，从事茶树生理、茶叶香气形成机理方面的研究多年，现任浙江大学城市学院法学院党委书记。\n\n徐波老师，原创意与艺术学院书记。钟情艺术，爱好音乐。愿与学生交流学术思想，分享人生经验，曾被学生昵称为“波哥”。担任博雅导师，与学员探讨艺术人生。“不要人夸颜色好，只留清气满乾坤”。朴实做人，踏实做事。博雅书院，师生共勉。\n \n杨海锋老师，浙江大学城市学院工商管理系教师，国家二级心理咨询师。发起创办生生学堂义塾、无形书院、健心房等文化公益组织，曾得多家媒体采访和报道。曾获第四届浙江省师德先进个人、浙江省教育系统“三育人”先进个人、第三届“最美杭州人——感动杭城十佳教师”、浙江大学城市学院“我最喜爱的老师”、浙江大学城市学院首届教学基本功比赛一等奖等。\n \n 赛来西·阿不都拉老师，浙江大学城市学院传媒与人文学院营销传播学系教师，副教授，公共关系方向负责人。她是浙江大学第五届师德先进个人、浙江省三育人先进、杭州市教育系统优秀教师，曾获得浙江大学和城市学院教学成果奖、我最喜爱的老师和中国大学生公共关系策划大赛优秀指导教师等多个荣誉。\n \n邵杨老师，中国传媒大学广播电视编导本科，浙江大学文学博士，从事当代影视文化及媒介批评研究，为多家媒体担任撰稿人与特约评论员，任教城院传媒分院广电专业四年，以课堂活跃、讲授风趣著称。\n \n 石苑老师，中国传媒大学传播学硕士/博士，研究方向有：传播仪式观、跨媒介叙事、迷文化研究。开设课程有：传播学概论、广播电视学、动画艺术赏析。业界项目有：2016年《我在这里等你——贵州省形象宣传片》文学统筹；2017年《“感动优衣库”品牌宣传片》制片助理。\n \n"
      },
      {
        title: "【博雅|纳新】精彩纷呈的博雅课程",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-课程介绍封面图.jpg",
        link: "../article01/article013/article013",
        content: "采编部：\n负责博雅书院的新闻稿和微信平台推送\n负责整合“悦”系列推送\n负责编辑学员感悟以及归档整理\n \n\宣传部：\n 负责日常课程或活动的拍照录像\n 负责制作宣传视频或者宣传册\n负责设计资信证书和结业证书\n通过线下方式宣传博雅书院\n\n秘书处：\n负责各活动的策划案、执行案和总结案的汇总\n 负责制定并执行部长和学员的培训和考核章程\n负责博雅书院各项活动财务预算全决算\n\n实践部：\n负责各类活动策划的实施、购置活动所需物品\n负责统筹博雅礼仪进分院活动\n负责统筹对外礼仪活动、学年小结、结业式等\n\n教学部：\n负责教学计划安排、联络老师、教室布置、签到结果最后统计\n负责编辑学员和后期教案的归档整理\n负责“年度优秀学员”评选\n\n"
      }, {
        title: "【博雅｜10月纳新】选择加入博雅的四大理由",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/【博雅书院-纳新】 900×500px.jpg",
        link: "../article06/article06",
        content: "【博雅｜10月纳新】选择加入博雅的四大理由"
      }, 
    ],

    navs: []
  },

  onLoad: function (options) {
    var page = this;
    var navs = this.loadNavData();
    page.setData({
      navs: navs
    });
  },
  navBtn: function (e) {
    console.log(e);


    var id = e.currentTarget.id;
    if (id == "3") {
      wx.navigateTo({
        url: '../article06/article06'
      })
    }

    var id = e.currentTarget.id;
    if (id == "2") {
      wx.navigateTo({
        url: '../article04/article04'
      })
    }

    var id = e.currentTarget.id;
    if (id == "1") {
      wx.navigateTo({
        url: '../article02/article02'
      })
    }

    var id = e.currentTarget.id;
    if (id == "0") {
      wx.navigateTo({
        url: '../article01/article01'
      })
    }
  },

  loadNavData: function () {
    var navs = [];
    var nav0 = new Object();
    nav0.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/1111111111111书院结构.png';
    nav0.name = '书院结构';
    navs[0] = nav0;

    var nav1 = new Object();
    nav1.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/2222222222222222书院活动.png';
    nav1.name = '书院活动';
    navs[1] = nav1;

    var nav2 = new Object();
    nav2.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/4444444444“悦”系列.png';
    nav2.name = '往期课程';
    navs[2] = nav2;



    var nav3 = new Object();
    nav3.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/666666666我的疑问.png';
    nav3.name = '加入博雅';
    navs[3] = nav3;



    return navs;
  },




  fHandin: function () {
    var that = this;


    wx.request({
      url: config.service.feedbackUrl,
      data: {
        team_name: that.data.team_name,
        advice1: that.data.advice1,
        advice2: that.data.advice2,
        advice3: that.data.advice3
      },
      method: 'POST',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        util.showSuccess('提交成功');
      },
      fail: function (res) {
        util.showModel('提交失败', '请检查你的网络连接是否正确');
      }
    })
  },

  onShareAppMessage: function () {
    return {
      title: 'ZUCC博雅书院呀',
      desc: '睿博|雅致|求是|创新',
      path: 'pages/home/home?id= wx0eb78264e0c81417'
    }
  },
})