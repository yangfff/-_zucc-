// pages/article01/article011/article011.js
  const app = getApp();

  Page({
    data: {
      article: [
        {
          title: "【博雅纳新|书院的圆梦导师团队】\n_______________________________________________________\n\n_______________________________________________________\n",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师封面图.jpg",
          content: "【博雅｜10月纳新】"
      },

        {
          title: "徐婧\n_______________________________________________________\n徐婧，博雅书院团队导师成员，菁礼仪形象工作室成员，国际形象礼仪培训师、中国形象礼仪讲师、中国赛会服务研究培训师、G20国际峰会志愿者形象礼仪通用培训师，国家二级心理咨询师。",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师-徐婧.jpg",
          content: "徐婧"
      }
        ,

        {
          title: "张如仟\n_______________________________________________________\n张如仟，国家高级礼仪培训师，学院博雅书院导师，计算学院学工办主任，开设《现代实用礼仪》等选修课，主讲课程《日常行为礼仪》和《社交礼仪》等。",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师-张如仟.jpg",
          content: "张如仟"
      }
        ,

        {
          title: "俞诗倩\n ______________________________________________________\n俞诗倩，博雅书院团队导师成员，浙江大学城市学院学工委教师，杭州师范大学法学硕士。热爱学生工作，热爱音乐、阅读，愿陪伴同学们一起寻一场非凡的文化之旅！",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师-俞诗倩.jpg",
          content: "俞诗倩"
      }
        ,

        {
          title: "伍曼菱\n_______________________________________________________\n伍曼菱，博雅书院辅导员导师成员，学院学工委学区辅导员，菁礼仪形象工作室成员，香港大学硕士，香港大学研究生会兼职对外汉语教师，主讲课程《形体礼仪》，热衷于研习中国传统文化。\n\n\n\n",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师-伍曼菱.jpg",
          content: "伍曼菱"
      }
        ,

        {
          title: "胡晓倩\n_______________________________________________________\n胡晓倩，浙江大学城市学院信电分院物理实验中心老师，在校期间获得浙大十佳志愿者，拱墅区最美志愿者，杭州市属高校最美大学生，校十佳主持。感恩生活，乐于奉献，愿与大家一起把研习礼仪变成一种习惯，让微笑变成日常基调，把学习与工作变成诗。\n\n\n\n",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-团队导师-胡晓倩.jpg",
          content: "胡晓倩"
      }
        ,

        {
          title: "来博雅 陪你看遍,烟波浩渺，星辰流光。.💫\n_______________________________________________________\n未尽事宜，请咨询：胡同学（15869482980）；曾同学（13516708521）\n_______________________________________________________\n\n_______________________________________________________\n 10月14纳新当日，我们在B02摊位等你！长按上方小程序码和公众号二维码，了解更多博雅资讯！\n\n\n\n\n_______________________________________________________\n",
          imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-纳新-二维码.png",
          content: "二维码"
      },


      ],

    },

    fHandin: function () {
    var that = this;


    wx.request({
      url: config.service.feedbackUrl,
      data: {
        team_name: that.data.team_name,
        advice1: that.data.advice1,
        advice2: that.data.advice2,
        advice3: that.data.advice3
      },
      method: 'POST',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        util.showSuccess('提交成功');
      },
      fail: function (res) {
        util.showModel('提交失败', '请检查你的网络连接是否正确');
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: 'zucc博雅书院-书院结构',
      desc: '快来pick这支超强导师、部门团队吧~',
      path: 'pages/article01/article01?id= wx0eb78264e0c81417'
    }
  },
})