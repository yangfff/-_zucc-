// pages/article04/article042/article042.js
const app = getApp();

Page({
  data: {
    article: [
      {
        title: "2017-2018学年_______________________________________________________\n_______________________________________________________\n世人闻秋悲寂寥，我道秋日胜春朝——博雅书院哲学主题课程;\n不傲才以骄人，不以宠而作威——学会沟通，拯救“尬聊”的沟通课程;\n华夏有衣，名曰汉服――博雅《华夏霓裳》主题课程;\n\n活动方寸亦有礼，工作之中存艺术——日常活动与工作中的礼仪;\n\n “随风潜入夜，润物细无声”——收获成长的博雅志愿者培训课程;\n\n一枝谈贮书窗下，人与花心各自香——博雅书院日式插花课程;\n礼者，人之所履——博雅书院形象礼仪课程;\n越女新妆出镜心，自知明艳更沉吟——博雅书院美妆课程;\n矮纸斜行闲作草，竹炉汤沸火初红。——博雅书院茶艺礼仪课程。\n\n更多课程信息，请关注“zucc博雅书院”微信公众号哦!\n\n_______________________________________________________\n",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-博雅纳新-课程介绍封面图.jpg",
        content: "【博雅·课程】精彩纷呈的博雅课程"
      },

      {
        title: "来博雅 陪你看遍,烟波浩渺，星辰流光。.💫\n_______________________________________________________\n未尽事宜，请咨询：胡同学（15869482980）；曾同学（13516708521）\n_______________________________________________________\n\n_______________________________________________________\n 10月14纳新当日，我们在B02摊位等你！长按上方小程序码和公众号二维码，了解更多博雅资讯！\n\n\n\n\n_______________________________________________________\n",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/20181011-纳新-二维码.png",
        content: "二维码"
      },
    ],

  },

  fHandin: function () {
    var that = this;


    wx.request({
      url: config.service.feedbackUrl,
      data: {
        team_name: that.data.team_name,
        advice1: that.data.advice1,
        advice2: that.data.advice2,
        advice3: that.data.advice3
      },
      method: 'POST',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        util.showSuccess('提交成功');
      },
      fail: function (res) {
        util.showModel('提交失败', '请检查你的网络连接是否正确');
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: '【博雅|课程】往期课程一览',
      desc: 'hey！我猜这里有你感兴趣的课程，而且参与还能拿素质分，快来看看吧！',
      path: 'pages/article04/article04?id= wx0eb78264e0c81417'
    }
  },
})



