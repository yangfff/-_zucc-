// pages/article073/article073.js
const app = getApp();
Page({
  /**
* 用户点击右上角分享
*/
  onShareAppMessage: function () {
    return {
      title: 'ZUCC更多文化类-超高质量活动',
      desc: '人生、社会、文化、哲学。。。用心甄选，只为你的“不虚此行”',
      path: 'pages/article07/article07?id= wx0eb78264e0c81417'
    }
  },
  
  data: {
    article: {
      title: "无形书院人文行走——重游文化故地 触摸人文脉搏",
      imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/33.jpg",
      content: "从无字句处读书——聊聊人文行走\n人文行走（早期称“游学参访”）是我发起的无形书院开展了多年的活动。因为参加我们行走的毕竟只是少数，我希望更多在杭州生活的同学，能在大学四年里，到杭州及周边的诸多人文遗迹走一走，熟悉熟悉、体贴体贴自己脚下这片土地上孕育的精神，不要和这座有着有山有水又有着深厚历史文化底蕴的城市失之交臂。\n 所以，我想给大家简单介绍一下，再和大家交流一下，意在帮助大家“DIY”属于你自己的人文行走，特别是如何做好前期的准备功课（人文行走不是旅游，它的前期功课很是一门学问哦）等等。课余的时间，可以自己一个人或者约上三五同好，出发……\n 部分我们走过的地方见http://www.sssch.net/ArticleList.aspx?C_ID=030401\n\n文章转自微信公众号“从内圣到外王”。"

    },
  }
})