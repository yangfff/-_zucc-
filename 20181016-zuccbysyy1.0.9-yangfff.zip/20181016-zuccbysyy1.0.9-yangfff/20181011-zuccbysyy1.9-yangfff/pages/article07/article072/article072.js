// pages/article072/article072.js
const app = getApp();
Page({
  /**
* 用户点击右上角分享
*/
  onShareAppMessage: function () {
    return {
      title: 'ZUCC更多文化类-超高质量活动',
      desc: '人生、社会、文化、哲学。。。用心甄选，只为你的“不虚此行”',
      path: 'pages/article07/article07?id= wx0eb78264e0c81417'
    }
  },
  
  data: {
    article: {
      title: "唧唧三人行往期漫谈主题一览",
      imgUrl1: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/22.jpg",
      imgUrl2:
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/唧唧二维码.bmp",
      content: "\n\n唧唧三人行第17弹单身狗，禁欲系，CP党青春期的压抑漫谈\n\n 唧唧三人行第16弹“不悲此日相逢晚，但恨君生我是师” ——师生之间的情感边界之惑\n\n 唧唧三人行第15弹“世人皆欲杀，我意独怜才”——逝去的李敖们和逝去的时代\n\n唧唧三人行第14弹：“今晚的月色真美”——文学艺术中的身体和情欲\n\n唧唧三人行第13弹： 从光棍节到购物节：“双十一”的情欲和物欲\\n\n\n更多精彩信息，欢迎关注“唧唧三人行”微信公众号哦~"

    },
  }
})