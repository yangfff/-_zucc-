// pages/home/home.js

Page({
  data: {
    indicatorDots: true,
    indicatorcolor: 'white',
    indicatoractivecolor: '#ADD8E6',
    autoplay: true,
    interval: 5000,
    duration: 1000,
    imgUrls: [
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/2.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/1.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/4.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/7.jpg",
      "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/10.jpg"
    ],
    article: [
      {
        title: "【博雅｜10月纳新】选择加入博雅的四大理由",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/【博雅书院-纳新】 900×500px.jpg",
        link: "../article06/article06",
        content: "【博雅｜10月纳新】选择加入博雅的四大理由"
      },

      {
        title: "【博雅｜往期课程】睿博、雅致、求是、创新",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/【博雅书院-往期课程】 900×500px.jpg",
        link: "../article04/article04",
        content: "博雅书院往期课程回顾"
      }
    ],

    navs: []
  },

  onLoad: function (options) {
    var page = this;
    var navs = this.loadNavData();
    page.setData({
      navs: navs
    });
  },
  navBtn: function (e) {
    console.log(e);


    var id = e.currentTarget.id;
    if (id == "3") {
      wx.navigateTo({
        url: '../article06/article06'
      })
    }

    var id = e.currentTarget.id;
    if (id == "2") {
      wx.navigateTo({
        url: '../article04/article04'
      })
    }

    var id = e.currentTarget.id;
    if (id == "1") {
      wx.navigateTo({
        url: '../article02/article02'
      })
    }

    var id = e.currentTarget.id;
    if (id == "0") {
      wx.navigateTo({
        url: '../article01/article01'
      })
    }
  },

  loadNavData: function () {
    var navs = [];
    var nav0 = new Object();
    nav0.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/1111111111111书院结构.png';
    nav0.name = '书院结构';
    navs[0] = nav0;

    var nav1 = new Object();
    nav1.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/2222222222222222书院活动.png';
    nav1.name = '书院活动';
    navs[1] = nav1;

    var nav2 = new Object();
    nav2.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/4444444444“悦”系列.png';
    nav2.name = '往期课程';
    navs[2] = nav2;



    var nav3 = new Object();
    nav3.img = 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/666666666我的疑问.png';
    nav3.name = '加入博雅';
    navs[3] = nav3;



    return navs;
  },




  fHandin: function () {
    var that = this;


    wx.request({
      url: config.service.feedbackUrl,
      data: {
        team_name: that.data.team_name,
        advice1: that.data.advice1,
        advice2: that.data.advice2,
        advice3: that.data.advice3
      },
      method: 'POST',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        util.showSuccess('提交成功');
      },
      fail: function (res) {
        util.showModel('提交失败', '请检查你的网络连接是否正确');
      }
    })
  },

  onShareAppMessage: function () {
    return {
      title: 'ZUCC博雅书院呀',
      desc: '睿博|雅致|求是|创新',
      path: 'pages/home/home?id= wx0eb78264e0c81417'
    }
  },
})