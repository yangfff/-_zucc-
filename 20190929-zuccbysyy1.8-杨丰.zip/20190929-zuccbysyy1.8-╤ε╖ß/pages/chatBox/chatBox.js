// pages/chatBox/chatBox.js
Page({
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '博雅机器人小姐姐——曹蒹葭',
      desc: '你想问的博雅小秘密，这里都有哦~机器人小姐姐乖巧等撩',
      path: 'pages/article07/article07?id= wx0eb78264e0c81417'
     
    }
  },
  fHandin: function () {
    var that = this;
    wx.request({
      url: config.service.feedbackUrl,
      data: {
        team_name: that.data.team_name,
        advice1: that.data.advice1,
        advice2: that.data.advice2,
        advice3: that.data.advice3
      },
      method: 'POST',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        util.showSuccess('提交成功');
      },
      fail: function (res) {
        util.showModel('提交失败', '请检查你的网络连接是否正确');
      }
    })
  },
  data: {
    inputValue: '',
    returnValue: '',
    allContentList: [],
    key: "6d8916401ae8497180930a2d32b125ae",
    num: 0,
    inputTemp: ''
  },
  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  submitTo: function (e) {

    let that = this;

    that.data.allContentList.push({ "value": that.data.inputValue });

    that.setData({
      allContentList: that.data.allContentList
    })
    let _url = `http://www.tuling123.com/openapi/api`;

    wx.request({
      url: _url,
      data: {
        key: that.data.key,
        info: that.data.inputValue
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        let data = res.data;
        if (data.code === 100000) {
          that.data.allContentList.push({ "value": data.text });
          that.setData({
            returnValue: data.text,
            allContentList: that.data.allContentList
          })

        } else {

        }

      }
    })
    that.inputTemp = '';
    //////

  },
  onLoad: function () {
    // 设置标题
    wx.setNavigationBarTitle({
      title: '聊天机器——小雅',
      success: function () {
        // console.log("success")
      },
      fail: function () {
        // console.log("error")
      }
    })
  }

})