// pages/chat/chat.js

var myPluginInterface = requirePlugin('myPlugin')
var wulAiSDK = require('WulAiSDK.js'); /*根据实际引用地址配置*/
Page({

  /**
  * 用户点击右上角分享
  */
  onShareAppMessage: function () {
    return {
      title: '博雅书院｜闲来雅叙',
      desc: '兄弟，快来和博小雅聊天吧~特别好玩',
      path: 'pages/article07/article07?id= wx0eb78264e0c81417'
    }
  },
  onLoad() {
    let pubkey = "y8MUsKiTvn6eUjHgdulZIpxvDSQShNtf00c1b37c34d0d83a81"
;
    let userinfo = {
      "avatar": "avatar", /*微信头像链接地址*/
      "nickname": "nickname", /*微信昵称*/
      "openid": "openid" /*用户微信openid或其他用户唯一标识*/
    }
    myPluginInterface.init(wulAiSDK, wx, null, pubkey, 'prod', userinfo, getApp(), true);
  }
})