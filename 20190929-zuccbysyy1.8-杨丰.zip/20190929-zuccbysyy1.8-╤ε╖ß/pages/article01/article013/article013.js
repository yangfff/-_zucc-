// pages/article01/article013/article013.js
const app = getApp();
Page({
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: 'zucc博雅书院-书院结构',
      desc: '快来pick这支超强导师、部门团队吧~',
      path: 'pages/article01/article01??id= wx0eb78264e0c81417'
    }
  },

  data: {
    article: {
      imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/部门.jpg",
      content: "采编部：\n负责博雅书院的新闻稿和微信平台推送\n负责整合“悦”系列推送\n负责编辑学员感悟以及归档整理\n \n\宣传部：\n 负责日常课程或活动的拍照录像\n 负责制作宣传视频或者宣传册\n负责设计资信证书和结业证书\n通过线下方式宣传博雅书院\n\n秘书处：\n负责各活动的策划案、执行案和总结案的汇总\n 负责制定并执行部长和学员的培训和考核章程\n负责博雅书院各项活动财务预算全决算\n\n实践部：\n负责各类活动策划的实施、购置活动所需物品\n负责统筹博雅礼仪进分院活动\n负责统筹对外礼仪活动、学年小结、结业式等\n\n教学部：\n负责教学计划安排、联络老师、教室布置、签到结果最后统计\n负责编辑学员和后期教案的归档整理\n负责“年度优秀学员”评选\n\n"
    }
  }
})