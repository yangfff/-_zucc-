// pages/article07/article07.js
Page({
  /**
  * 用户点击右上角分享
  */
  onShareAppMessage: function () {
    return {
      title: 'ZUCC更多文化类-超高质量活动',
      desc: '人生、社会、文化、哲学。。。用心甄选，只为你的“不虚此行”',
      path: 'pages/article07/article07?id= wx0eb78264e0c81417'
    }
  },

  /**
   * 页面的初始数据
   */
  data: {

    article: [
      {
        title: "无行书院经典会读——经典启发 真诚对话 生命的成长",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/11.jpg",
        link: "../article07/article071/article071",
        content: "经典启发 真诚对话 生命的成长   \n指导老师：杨海峰\n\n"
      },
      {
        title: "唧唧三人行——经典解读 文化传播",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/22.jpg",
        link: "../article07/article072/article072",
        content: "经典解读 文化传播   \n指导老师：邵阳、石苑、蔡渊迪\n \n"
      },

      {
        title: "无形书院人文行走——重游文化故地 触摸人文脉搏",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/33.jpg",
        link: "../article07/article073/article073",
        content: "重游文化故地 触摸人文脉搏 \n  指导老师：杨海峰\n \n"
      },
      {
        title: "日新晨读——青年日新 从晨读起 日新晨读 自经典始",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/44.jpg",
        link: "../article07/article074/article074",
        content: "青年日新 从晨读起 日新晨读 自经典始 \n  指导老师：杨海峰\n \n"
      },
      {
        title: "健心房沙龙——以书为媒 探索人生 疗愈心灵 启发生命",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/55.jpg",
        link: "../article07/article075/article075",
        content: "以书为媒 探索人生 疗愈心灵 启发生命  \n 指导老师：杨海峰\n \n"
      },
     {
        title: "尼采-亚隆读书小组——探讨西方哲学 品味人生百态",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/66.jpg",
        link: "../article07/article076/article076",
        content: "  探讨西方哲学 品味人生百态 \n指导老师：张鑫焱\n \n"
      },
     {
        title: "从内圣到外王——对人生、社会、文化等的思考",
        imgUrl: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/77.jpg",
        link: "../article07/article077/article077",
        content: "对人生、社会、文化等的思考  \n指导老师：杨海峰\n\n"
      }
    ]
  }
})