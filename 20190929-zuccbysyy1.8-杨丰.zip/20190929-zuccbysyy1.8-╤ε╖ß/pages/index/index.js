// pages/index/index.js 
var util = require('../../utils/util.js');
Page({

  /** 
   * 页面的初始数据 
   */
  data: {
    currentIndex: 0,
    cardRightIn: false,
    cardLeftIn: false
  },

  /** 
   * 生命周期函数--监听页面加载 
   */
  onLoad: function (options) {
    let list = [

      {
        _id: "6",
        tag: '2018-博雅纳新',
        author: "10月8日开启",
        cover: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/【博雅书院-纳新】 900×500px.jpg",
        time: "2018年03月17日 ",
        title: "2018年博雅书院纳新即将启动，敬请期待。",
        agree: false,
        agreeNum: 880,
        commentNum: 267,
        comment: [
          {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/女1.jpg',
            name: '羊羊羊',
            txt: '学姐学长，请问博雅书院是怎么样的一个组织呢？',
            fromNow: '2天前'
          },
          {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！彬瑄小可爱.jpg',
          name: '彬瑄小可爱回复羊羊羊',
          txt: '博雅书院以高素质人才培养理念为引领，以传播中华传统礼仪及礼仪为重点，以培养学生的社会这人以传播中华传统礼仪及文化为重点，以培养学生的社会责任、礼仪素养和人文艺术品味为主要内容，特别是结合学生日常行为规范和生活礼仪的实践，通过课堂讲座、互动自省和项目践行等三个环节的教学计划和针对性的课程设置，塑造学生“睿博、雅致、大气、求是”的理想人格和生活气质。',
          fromNow: '2天前'
        }, {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！佳蕾.jpg',
            name: '严二谨',
            txt: '请问博雅书院都有哪些部门呢？',
            fromNow: '2天前'
          },
          {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！育佳学姐.jpg',
            name: '育佳学姐回复严二谨',
            txt: '采编部、宣传部、秘书处、实践部、教学部哦~',
            fromNow: '2天前'
          }, {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/女可爱女.jpg',
            name: 'triple',
            txt: '怎样才能成为博雅书院的学员呢？',
            fromNow: '2天前'
          },
          {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！CC姐.jpg',
            name: 'CC姐回复triple',
            txt: '博雅书院面向大一大二招生，对报名者经过资格审查后进行笔试面试考核，通过考核者将面临一个月考察期，通过考察期的学员将正式成为博雅书院的学员。',
            fromNow: '2天前'
          },
          {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/男1.jpg',
            name: '时卿。',
            txt: '没有传统文化底蕴的人可以进入博雅书院吗？',
            fromNow: '1天前'

          },
          {
            logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！露露小可爱.jpg',
            name: 'CC姐',
            txt: '博雅书院以培养学生的社会责任、礼仪素养和人文艺术品味为主要内容，特别是结合学生日常行为规范和生活礼仪的实践，通过课堂讲座、互动自省和项目践行等三个环节的教学计划和针对性的课程设置，塑造学生“睿博、雅致、大气、求是”的理想人格和生活气质，没有才来培养嘛！',
            fromNow: '1天前'
          },
        ]
      },




      {
        _id: "5",
        tag: '2018-博雅素拓',
        author: "教学部",
        cover: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！！素拓2 - 副本.jpg",
        time: "2018年03月17日",
        title: "博雅素拓终于完啦。真的不容易。各位都超级棒，给各位比小心心。",
        agree: false,
        agreeNum: 590,
        commentNum: 107,
        comment: [{
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！彬瑄小可爱.jpg',
          name: '彬瑄小可爱',
          txt: '谢谢教学的素拓策划还有博雅的同学们，今天超级开心的！！！',
          fromNow: '6个月前'
        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！佳蕾.jpg',
          name: '佳蕾',
          txt: '喜欢博雅！比心~',
          fromNow: '6个月前'
        },
        {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！金崇.png',
          name: '崇',
          txt: '喜欢大家！比心~',
          fromNow: '6个月前'
        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！育佳学姐.jpg',
          name: '育佳学姐',
          txt: '纪念一下前十名选手全是博雅书院朋友的盛况，宝贝们今天都超级哒！',
          fromNow: '6个月前'
        },
        {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/!杨丰.jpg',
          name: '仙仙仙仙仙女组',
          txt: '博雅素拓结束ヽ(；▽；)ノ一个上午走了将近两万步！又累又爽！仙仙仙仙仙女组🧚‍团结就是力量，坚持就是胜利',
          fromNow: '6个月前'
        },
        {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！迪雅.jpg',
          name: '迪雅',
          txt: '博雅素拓终于完啦。真的不容易。各位都超级棒，给各位比小心心。教学部的各位真的非常辛苦了，一步步策划踩点到今天当工作人员折腾。 与君初相识，犹如故人归。 地球不爆炸，教学不分家。',
          fromNow: '6个月前'

        },
        ]
      },



      {
        _id: "4",
        tag: '博雅汉服主题课',
        author: "金崇",
        cover: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！！汉服课.png",
        time: "2018年04月18日 ",
        title: "刚才在博雅第一次穿了汉服(〃ω〃)那套汉服似乎是唐朝的款式，面料十分厚重，绣花相当有质感！因为没有镜子，我自己不知道穿着是什么样的，但穿上感觉一下子就很快乐(⁄ ⁄•⁄ω⁄•⁄ ⁄)很幸运的体验！感谢崇正雅集华服社！",
        agree: false,
        agreeNum: 236,
        commentNum: 47,
        comment: [{
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！CC姐.jpg',
          name: 'CC姐',
          txt: '哈哈哈好看！',
          fromNow: '5个月前'

        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！金崇.png',
          name: '崇回复CC姐',
          txt: '谢谢！好期待皂片！(〃∀〃)',
          fromNow: '5个月前'
        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！顾炜.jpg',
          name: '本次的课程主讲“顾炜”学姐',
          txt: '第一次以主讲人的身份去介绍汉服，第一次拥有自己的台签，第一次接受与汉服有关的采访。感谢博雅书院给我这个机会。如果没有汉服，一定不会有现在的我。我能够站上讲台的自信与勇气，都来源于对汉服的爱。  谢谢璇璇的支持，帮我一起改PPT、固定发型，还在现场帮学员们试穿汉服。还要表白迪雅，去一趟博雅能“蹭”到美丽的照片真是意外之喜～',
          fromNow: '5个月前'
        },
        {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/!杨丰.jpg',
          name: '丰丰',
          txt: '本周的博雅汉服课程好好玩哦~满足(￣▽￣～)~',
          fromNow: '5个月前'
        },
        ]
      },



      {
        _id: "2",
        tag: '陈佳莉',
        author: "季忆河",
        cover: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！！教学生日.jpg",
        createtime: 1522026765222,
        time: "2018年03月23日 ",
        title: "教学部二位成员的生日会，欢乐与感动。地球不爆炸，教学不分家！",
        agree: false,
        agreeNum: 525,
        commentNum: 86,

        comment: [{
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！忆河.jpg',
          name: '忆河',
          txt: '转眼十九，碌碌无为。却因缘分拥有了你们。初入博雅，再识教学。因你们精彩，也因你们皮，感谢自己，在最好的时光遇见了你们。。。总结一句话，地球不爆炸，教学不分家。(ps:祝自己生日快乐。。提前[捂脸][捂脸])  这文笔打扰了。。。',
          fromNow: '6个月前'
        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/!杨丰.jpg',
          name: '丰丰',
          txt: '以前常说道，最最希望能不偏不倚，让我恰恰在最美好的年纪遇见的最美好你。现在才知道这个“你”确乎是“你们”了，幼稚又聪慧的团宠佳莉大宝贝，全幼儿园最可爱的季大爷，全幼儿园最帅气的陈大少，还有娘的小宝贝迪雅，不能不管的幼稚鬼曾大爷，以及脱单小分队的VIP大佬 我们的口号是什么？地球不爆炸，教学不分家  什么没听清[疑问][疑问][疑问]佳莉姐，季可爱生日快乐!!!',
          fromNow: '6个月前'
        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！迪雅.jpg',
          name: '迪雅',
          txt: '今日博雅举行了教学部二位成员的生日会，气氛热烈而和睦。会后，与会嘉宾还共同商讨了博雅发展大计，展望未来，占位高处。最后衷心的祝愿二位成员生日快乐，博雅越来越好。让我们再来重温一次教学部口号： 地球不爆炸，教学不分家。',
          fromNow: '6个月前'
        },]
      },
      {
        _id: "3",
        tag: '博雅学员结业',
        author: "部门照",
        cover: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/部门照片.jpg",
        time: "2018年09月14日 ",
        title: "不知不觉又一年。转眼间我也成了老学姐。最神奇的部门合照。拍合照的时候不在杭州就视频打给我，然后一起拍合照。又看了一遍之前想给博雅做宣传拍的视频，真的泪目。\n最遗憾的大概就是没有留任博雅了吧。\n 真的感谢在博雅遇到你们。我喜欢博雅书院，更喜欢你们。\n",
        agree: false,
        agreeNum: 364,
        commentNum: 62,
      },
      {
        _id: "1",
        tag: '教学优秀日常',
        author: "韩房迪雅",
        cover: "https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/!！迪雅小诗.jpg",
        createtime: 1523216765222,
        time: "2018年04月28日 ",
        title: "闲来无事填个小歌词。\n填给博雅，也填给教学部。\n共学东西同创南北，看蓝天碧水听风雷。\n 年年春花惹人醉，岁岁秋叶扫眼眉。\n只愿书院千古，不曾俗随",
        agree: false,
        agreeNum: 93,
        commentNum: 22,
        comment: [{
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！CC姐.jpg',
          name: 'CC姐',
          txt: '是时候拿出全民k歌了',
          fromNow: '5个月前'

        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！迪雅.jpg',
          name: '迪雅回复CC姐',
          txt: '嘻嘻嘻√',
          fromNow: '5个月前'
        }, {
          logo: 'https://lg-op7d4z6q-1257103730.cos.ap-shanghai.myqcloud.com/！曾.jpg',
          name: '曾',
          txt: '我们迪雅~优秀！',
          fromNow: '5个月前'
        },]
      },





    ]
    this.setData({
      list
    })
  },

  /** 
   * 生命周期函数--监听页面初次渲染完成 
   */
  onReady: function () {

  },

  /** 
   * 生命周期函数--监听页面显示 
   */
  onShow: function () {

  },
  toAgree: function (e) {
    let id = e.currentTarget.dataset.id;
    let list = this.data.list
    for (let i of list) {
      if (i._id == id) {
        i.agree = !i.agree
      }
      if (i._id == id && i.agree) {
        i.agreeNum = i.agreeNum + 1
      } else if (i._id == id && !i.agree) {
        i.agreeNum = i.agreeNum - 1
      }
      this.setData({
        list
      })
    }
  },
  toComment: function () {
    console.log('comment')
  },
  //手指触摸动作开始 记录起点X坐标 
  touchstart: function (e) {
    this.setData({
      startX: e.changedTouches[0].clientX,
      startY: e.changedTouches[0].clientY
    })
  },
  //滑动事件处理 
  touchmove: function (e) {
    let idx = e.currentTarget.dataset.index;
    let startX = this.data.startX, //开始X坐标 
      startY = this.data.startY, //开始Y坐标 
      touchMoveX = e.changedTouches[0].clientX, //滑动变化坐标 
      touchMoveY = e.changedTouches[0].clientY, //滑动变化坐标 
      //获取滑动角度 
      angle = this.angle({
        X: startX,
        Y: startY
      }, {
          X: touchMoveX,
          Y: touchMoveY
        });

    //滑动超过45度角 return 
    if (Math.abs(angle) > 45) return;

    if (touchMoveX > startX) { //右滑 
      this.setData({
        currentIndex: idx == 0 ? 0 : idx - 1,
        cardRightIn: false,
        cardLeftIn: true
      })
    } else {
      this.setData({
        currentIndex: idx == this.data.list.length - 1 ? idx : idx + 1,
        cardRightIn: true,
        cardLeftIn: false
      })
    }
    wx.pageScrollTo({
      scrollTop: 0
    })

  },
  /** 
   * 计算滑动角度 
   * @param {Object} start 起点坐标 
   * @param {Object} end 终点坐标 
   */
  angle: function (start, end) {
    var _X = end.X - start.X,
      _Y = end.Y - start.Y
    //返回角度 /Math.atan()返回数字的反正切值 
    return 360 * Math.atan(_Y / _X) / (2 * Math.PI)
  },

  /** 
   * 生命周期函数--监听页面隐藏 
   */
  onHide: function () {

  },

  /** 
   * 生命周期函数--监听页面卸载 
   */
  onUnload: function () {

  },

  /** 
   * 页面相关事件处理函数--监听用户下拉动作 
   */
  onPullDownRefresh: function () {

  },

  /** 
   * 页面上拉触底事件的处理函数 
   */
  onReachBottom: function () {

  },

  /** 
   * 用户点击右上角分享 
   */
  onShareAppMessage: function () {

  }
})